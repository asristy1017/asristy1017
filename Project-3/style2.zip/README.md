# Website based on core HTML and CSS.

> Author - Ravi Raushan Kumar ( ReyanshRavi )

    In this project I learned a lot.
        1. Position alignment
        2. Flexbox
        3. How to write CSS in a manner way.
        4. Proper way to write selector.
        5. Image alignment.

> You can checkout these codes on github also.
[Project-3 on github](https://github.com/reyanshravi/Project-3)

> Also Checkout the demo on netlify.
[Netlify Demo](https://reyanshraviproj3.netlify.app/)
